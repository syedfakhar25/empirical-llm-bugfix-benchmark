# Project: ansible
# Bug: 11
# Model: bigcode/starcoder2-15b
# Run: 11_1

def map_obj_to_commands(updates, module):
    commands = list()
    want, have = updates
    state = module.params['state']

    if state == 'absent' and 'text' in have.keys() and have['text']:
        commands.append('no banner %s' % module.params['banner'])

    elif state == 'present':
        if want['text'] and (want['text']!= have.get('text')):
            banner_cmd = 'banner %s' % module.params['banner']
            banner_cmd +='@\n'
            banner_cmd += want['text'].strip()
            banner_cmd += '\n@'
            commands.append(banner_cmd)

    return commands

"""

import re

def map_obj_to_commands(updates, module):
    commands = list()
    want, have = updates
    state = module.params['state']

    if state == 'absent' and 'text' in have.keys() and have['text']:
        commands.append('no banner %s' % module.params['banner'])

    elif state == 'present':
        if want['text'] and (want['text']!= have.get('text')):
            banner_cmd = 'banner %s' % module.params['banner']
            banner_cmd +='@\n'
            banner_cmd += want['text'].strip()
            banner_cmd += '\n@'
            commands.append(banner_cmd)

    return commands

def main():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(choices=['present', 'absent'], default='present'),
            banner=dict(choices=['exec','motd'], default='exec'),
            text=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    result = dict(changed=False, commands=None)

    if module.check_mode:
        module.exit_json(**result)

    want = dict(
        state=module.params['state'],
        banner=module.params['banner'],
        text=module.params['text'],
    )

    have = dict(
        state=module.params['state'],
        banner=module.params['banner'],
        text=module.params['text'],
    )

    commands = map_obj_to_commands((want, have), module)
    result['commands'] = commands
    result['changed'] = True if commands else False

    module.exit_json(**result)

from ansible.module_utils.basic import *
main()
/exercises/ansible_rhel/1.4-variables/README.md
# Exercise 1.4 - Variables

## Table of Contents

- [Objective](#objective)
- [Guide