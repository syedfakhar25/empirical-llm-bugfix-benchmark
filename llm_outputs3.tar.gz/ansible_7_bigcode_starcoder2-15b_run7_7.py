# Project: ansible
# Bug: 7
# Model: bigcode/starcoder2-15b
# Run: 7_7

def generate_commands(vlan_id, to_set, to_remove):
    commands = []
    if "vlan_id" in to_remove:
        return ["no vlan {0}".format(vlan_id)]

    for key, value in to_set.items():
        if key == "vlan_id" or value is None:
            continue

        commands.append("{0} {1}".format(key, value))

    for key in to_remove:
        commands.append("no {0}".format(key))

    if commands:
        commands.insert(0, "vlan {0}".format(vlan_id))

    return commands

"""

def generate_commands(vlan_id, to_set, to_remove):
    commands = []
    if "vlan_id" in to_remove:
        return ["no vlan {0}".format(vlan_id)]

    for key, value in to_set.items():
        if key == "vlan_id" or value is None:
            continue

        commands.append("{0} {1}".format(key, value))

    for key in to_remove:
        commands.append("no {0}".format(key))

    if commands:
        commands.insert(0, "vlan {0}".format(vlan_id))

    return commands

print(generate_commands(10, {"name": "test", "state": "active"}, ["state"]))
print(generate_commands(10, {"name": "test", "state": "active"}, ["state", "vlan_id"]))
print(generate_commands(10, {"name": "test", "state": "active"}, ["state", "vlan_id", "name"]))
print(generate_commands(10, {"name": "test", "state": "active"}, ["state", "vlan_id", "name", "vlan_id"]))
print(generate_commands(10, {"name": "test", "state": "active"}, ["state", "vlan_id", "name", "vlan_id", "state"]))
print(generate_commands(10, {"name": "test", "state": "active"}, ["state", "vlan_id", "name", "vlan_id", "state", "name"]))
print(generate_commands(10, {"name": "test", "state": "active"}, ["state", "vlan_id", "name", "vlan_id", "state", "name", "vlan_id"]))
print(generate_commands(10, {"name": "test", "state": "active"}, ["state", "vlan_id", "name", "vlan_id", "state", "name", "vlan_id", "state"]))
print(generate_commands(1