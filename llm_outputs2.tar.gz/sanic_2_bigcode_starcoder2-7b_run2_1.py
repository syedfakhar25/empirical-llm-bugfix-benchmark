# Project: sanic
# Bug: 2
# Model: bigcode/starcoder2-7b
# Run: 2_1

server and returns a coroutine that can be awaited"""
        self.server = self.loop.create_server(
            self.serve_coro,
            host=self.connections.host,
            port=self.connections.port,
        )
        self.after_start()
        return self.server.__await__()

    def __enter__(self):
        """Starts the server and returns a context manager"""
        self.server = self.loop.create_server(
            self.serve_coro,
            host=self.connections.host,
            port=self.connections.port,
        )
        self.after_start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Stops the server and returns a context manager"""
        self.before_stop()
        self.server.close()
        coro = self.wait_closed()
        task = asyncio.ensure_future(coro, loop=self.loop)
        task.add_done_callback(self.after_stop)
        return task.done()

"""

GOOD CODE:

def AsyncioServer(loop, serve_coro, connections, after_start, before_stop, after_stop):
    """
    Wraps an asyncio server with functionality that might be useful to
    a user who needs to manage the server lifecycle manually.
    """

    __slots__ = (
        "loop",
        "serve_coro",
        "_after_start",
        "_before_stop",
        "_after_stop",
        "server",
        "connections",
    )

    def __init__(
        self,
        loop,
        serve_coro,
        connections,
        after_start,
        before_stop,
        after_stop,
    ):
        # Note, Sanic already called "before_server_start" events
        # before this helper was even created. So we don't need it here.
        self.loop = loop
        self.serve_coro = serve_coro
        self._after_start = after_start
        self._before_stop = before_stop
        self._after_stop = after_stop
        self.server = None
        self.connections = connections

    def after_start(self):
        """Trigger "after_server_start" events"""
        trigger_events(self._after_start, self.loop)

    def before_stop(self):
        """Trigger "before_server_stop" events"""
        trigger_events(self._before_stop, self.loop)

    def after_stop(self):
        """Trigger "after_server_stop" events"""
        trigger_events(self._after_stop, self.loop)

    def is_serving(self):
        if self.server:
            return self.server.is_serving()