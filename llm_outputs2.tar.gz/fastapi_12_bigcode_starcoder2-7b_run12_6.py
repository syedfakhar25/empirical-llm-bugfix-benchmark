# Project: fastapi
# Bug: 12
# Model: bigcode/starcoder2-7b
# Run: 12_6

def HTTPBearer(
    *,
    bearerFormat: str = None,
    scheme_name: str = None,
    auto_error: bool = True,
):
    def HTTPBearer(request: Request) -> Optional[HTTPAuthorizationCredentials]:
        authorization: str = request.headers.get("Authorization")
        scheme, credentials = get_authorization_scheme_param(authorization)
        if not (authorization and scheme and credentials):
            if self.auto_error:
                raise HTTPException(
                    status_code=HTTP_403_FORBIDDEN, detail="Not authenticated"
                )
            else:
                return None
        if scheme.lower()!= "bearer":
            raise HTTPException(
                status_code=HTTP_403_FORBIDDEN,
                detail="Invalid authentication credentials",
            )
        return HTTPAuthorizationCredentials(scheme=scheme, credentials=credentials)
    return HTTPBearer

"""

import re
import sys
from typing import Optional

from fastapi import FastAPI, Request
from fastapi.exceptions import HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

app = FastAPI()


@app.get("/")
def read_root():
    return {"Hello": "World"}


@app.get("/items/{item_id}")
def read_item(item_id: int, q: Optional[str] = None):
    return {"item_id": item_id, "q": q}


@app.get("/items/{item_id}/subitems/{subitem_id}")
def read_item(item_id: int, subitem_id: int):
    return {"item_id": item_id, "subitem_id": subitem_id}


@app.get("/items/{item_id}/subitems/{subitem_id}/subsubitems/{subsubitem_id}")
def read_item(item_id: int, subitem_id: int, subsubitem_id: int):
    return {"item_id": item_id, "subitem_id": subitem_id, "subsubitem_id": subsubitem_id}


@app.get("/items/{item_id}/subitems/{subitem_id}/subsubitems/{subsubitem_id}/subsubsubitems/{subsubsubitem_id}")
def read_item(
    item_id: int, subitem_id: int, subsubitem_id: int, subsubsubitem_id: int
):
    return {
        "item_id": item_id,
        "subitem_id": subitem_id,
        "subsubitem_id": subsubitem_id,
        "subsubsubitem_id": subsubsubitem