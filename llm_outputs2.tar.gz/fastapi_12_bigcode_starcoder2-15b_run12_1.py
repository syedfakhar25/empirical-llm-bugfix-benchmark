# Project: fastapi
# Bug: 12
# Model: bigcode/starcoder2-15b
# Run: 12_1

"""

import inspect
import re
from typing import Optional

from fastapi import HTTPException, Request
from fastapi.security.base import HTTPAuthorizationCredentials, HTTPBase
from fastapi.security.utils import get_authorization_scheme_param
from starlette.status import HTTP_403_FORBIDDEN


class HTTPBearer(HTTPBase):
    def __init__(
        self,
        *,
        bearerFormat: str = None,
        scheme_name: str = None,
        auto_error: bool = True,
    ):
        self.model = HTTPBearerModel(bearerFormat=bearerFormat)
        self.scheme_name = scheme_name or self.__class__.__name__
        self.auto_error = auto_error

    async def __call__(
        self, request: Request
    ) -> Optional[HTTPAuthorizationCredentials]:
        authorization: str = request.headers.get("Authorization")
        scheme, credentials = get_authorization_scheme_param(authorization)
        if not (authorization and scheme and credentials):
            if self.auto_error:
                raise HTTPException(
                    status_code=HTTP_403_FORBIDDEN, detail="Not authenticated"
                )
            else:
                return None
        if scheme.lower()!= "bearer":
            raise HTTPException(
                status_code=HTTP_403_FORBIDDEN,
                detail="Invalid authentication credentials",
            )
        return HTTPAuthorizationCredentials(scheme=scheme, credentials=credentials)


def test_code():
    assert inspect.isclass(HTTPBearer)
    assert HTTPBearer.__name__ == "HTTPBearer"
    assert HTTPBearer.__doc__ == "Fix the following class named 'HTTPBearer'."
    assert HTTPBearer.__init__.__doc__ == "Initialize self.  See help(type(self)) for accurate signature."
    assert HTTPBearer.__call__.__doc__ == "Call self as a function."
    assert HTTPBearer.__init__.__annotations__["bearerFormat"] == str
    assert HTTPBearer.__init__.__annotations__["scheme_name"] == str
    assert HTTPBearer.__init__.__annotations__["auto_error"] == bool
    assert HTTPBearer.__call__.__annotations__["request"] == Request
    assert HTTPBearer.__call__.__annotations__["return"] == Optional[HTTPAuthorizationCredentials]
    assert HTTPBearer.__init__.__defaults__ == (None, None, True)
    assert HTTPBearer.__init__.__kwdefaults__ == {}
    assert HTTPBearer.__call__.__defaults__ == ()
    assert HTTPBearer.__call__.__kwdefaults__ == {}
    assert HTTPBearer.__init__.__code__.co_argcount == 4
    assert HTTPBearer.__call__.__code__.co_argcount == 2
    assert HTTPBearer.__init__.__code__.co_kwonlyargcount == 0
    assert HTTPBearer.__call__.__code__.co_kwonlyargcount == 0