# Project: scrapy
# Bug: 9
# Model: codellama/CodeLlama-13b-Instruct-hf
# Run: 9_6

if isinstance(body, unicode):
            body = body.encode(charset or 'utf-8')
        msg.attach(MIMEText(body, _subtype=mimetype))
        for attach in attachs:
            part = MIMEBase(*mimetype.split('/', 1))
            part.set_payload(open(attach, 'rb').read())
            Encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(attach))
            msg.attach(part)
        try:
            s = smtplib.SMTP(self.smtphost, self.smtpport)
            if self.smtpuser and self.smtppass:
                s.login(self.smtpuser, self.smtppass)
            if self.smtptls:
                s.starttls()
            if self.smtpssl:
                s.starttls()
            s.sendmail(self.mailfrom, rcpts, msg.as_string())
            s.quit()
        except smtplib.SMTPException as e:
            if _callback:
                _callback(e)
            else:
                raise

    def close(self):
        pass