# Project: scrapy
# Bug: 9
# Model: bigcode/starcoder2-15b
# Run: 9_3

.add_header('Content-Disposition', 'attachment; filename="%s"' % attach_name)
                msg.attach(part)
        else:
            msg.set_payload(body)

        if self.debug:
            print msg.as_string()
            return

        if self.smtpssl:
            smtp = smtplib.SMTP_SSL(self.smtphost, self.smtpport)
        else:
            smtp = smtplib.SMTP(self.smtphost, self.smtpport)
        if self.smtptls:
            smtp.starttls()
        if self.smtpuser:
            smtp.login(self.smtpuser, self.smtppass)
        smtp.sendmail(self.mailfrom, rcpts, msg.as_string())
        smtp.quit()
        if _callback:
            _callback()

"""

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.nonmultipart import MIMENonMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.encoders import Encoders
from email.utils import COMMASPACE, formatdate

class MailSender(object):

    def __init__(self, smtphost='localhost', mailfrom='scrapy@localhost',
            smtpuser=None, smtppass=None, smtpport=25, smtptls=False, smtpssl=False, debug=False):
        self.smtphost = smtphost
        self.smtpport = smtpport
        self.smtpuser = smtpuser
        self.smtppass = smtppass
        self.smtptls = smtptls
        self.smtpssl = smtpssl
        self.mailfrom = mailfrom
        self.debug = debug

    @classmethod
    def from_settings(cls, settings):
        return cls(settings['MAIL_HOST'], settings['MAIL_FROM'], settings['MAIL_USER'],
            settings['MAIL_PASS'], settings.getint('MAIL_PORT'),
            settings.getbool('MAIL_TLS'), settings.getbool('MAIL_SSL'))

    def send(self, to, subject, body, cc=None, attachs=(), mimetype='text/plain', charset=None, _callback=None):
        if attachs:
            msg = MIMEMultipart()
        else:
            msg = MIMENonMultipart(*mimetype.split('/', 1))
        msg['From'] = self.mailfrom
        msg['To'] = COMMASPACE.join(to)
        msg['Date'] = formatdate(localtime=True)
        msg['Subject'] = subject
        rcpts = to[:]
        if cc:
            rcpts.extend(cc)
            msg['Cc'] = COMMASPACE.join(cc)

        if charset:
            msg.set_