# Project: scrapy
# Bug: 5
# Model: deepseek-ai/deepseek-coder-6.7b-instruct
# Run: 5_2

return "<%d %s>" % (self.status, self.url)

    def __repr__(self):
        return "<Response %d %s>" % (self.status, self.url)

FIXED CODE:
```python
class Response:

    def __init__(self, url, status=200, headers=None, body=b'', flags=None, request=None):
        self.headers = Headers(headers or {})
        self.status = int(status)
        self._set_body(body)
        self._set_url(url)
        self.request = request
        self.flags = [] if flags is None else list(flags)

    @property
    def meta(self):
        try:
            return self.request.meta
        except AttributeError:
            raise AttributeError(
                "Response.meta not available, this response "
                "is not tied to any request"
            )

    def _get_url(self):
        return self._url

    def _set_url(self, url):
        if isinstance(url, str):
            self._url = url
        else:
            raise TypeError('%s url must be str, got %s:' % (type(self).__name__,
                type(url).__name__))

    url = property(_get_url, _set_url)

    def _get_body(self):
        return self._body

    def _set_body(self, body):
        if body is None:
            self._body = b''
        elif not isinstance(body, bytes):
            raise TypeError(
                "Response body must be bytes. "
                "If you want to pass unicode body use TextResponse "
                "or HtmlResponse.")
        else:
            self._body = body

    body = property(_get_body, _set_body)

    def __str__(self):
        return "<%d %s>" % (self.status, self.url)

    def __repr__(self):
        return "<Response %d %s>" % (self.status, self.url)
```

```