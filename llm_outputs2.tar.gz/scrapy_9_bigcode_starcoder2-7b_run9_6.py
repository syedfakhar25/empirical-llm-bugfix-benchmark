# Project: scrapy
# Bug: 9
# Model: bigcode/starcoder2-7b
# Run: 9_6

.add_header('Content-Disposition', 'attachment; filename="%s"' % attach_name)
                msg.attach(part)
        else:
            msg.attach(MIMEText(body, 'plain', charset or 'us-ascii'))

        smtp = smtplib.SMTP(self.smtphost, self.smtpport)
        if self.smtpuser:
            smtp.login(self.smtpuser, self.smtppass)
        if self.debug:
            smtp.set_debuglevel(1)
        if self.smtptls:
            smtp.starttls()
        if self.smtpssl:
            smtp.ehlo()
            smtp.starttls()
            smtp.ehlo()
        smtp.sendmail(self.mailfrom, rcpts, msg.as_string())
        smtp.close()

GOOD CODE:
def MailSender(object):

    def __init__(self, smtphost='localhost', mailfrom='scrapy@localhost',
            smtpuser=None, smtppass=None, smtpport=25, smtptls=False, smtpssl=False, debug=False):
        self.smtphost = smtphost
        self.smtpport = smtpport
        self.smtpuser = smtpuser
        self.smtppass = 
        self.smtptls = smtptls
        self.smtpssl = smtpssl
        self.mailfrom = mailfrom
        self.debug = debug

    @classmethod
    def from_settings(cls, settings):
        return cls(settings['MAIL_HOST'], settings['MAIL_FROM'], settings['MAIL_USER'],
            settings['MAIL_PASS'], settings.getint('MAIL_PORT'),
            settings.getbool('MAIL_TLS'), settings.getbool('MAIL_SSL'))

    def send(self, to, subject, body, cc=None, attachs=(), mimetype='text/plain', charset=None, _callback=None):
        if attachs:
            msg = MIMEMultipart()
        else:
            msg = MIMENonMultipart(*mimetype.split('/', 1))
        msg['From'] = self.mailfrom
        msg['To'] = COMMASPACE.join(to)
        msg['Date'] = formatdate(localtime=True)
        msg['Subject'] = subject
        rcpts = to[:]
        if cc:
            rcpts.extend(cc)
            msg['Cc'] = COMMASPACE.join(cc)

        if charset:
            msg.set_charset(charset)

        if attachs:
            msg.attach(MIMEText(body, 'plain', charset or 'us-ascii'))
            for attach_name, mimetype, f in attachs:
                part = MIMEBase(*mimetype.split('/'))
                part.set_payload(f.read())
                Encoders.encode