# Project: luigi
# Bug: 7
# Model: Qwen/Qwen2.5-Coder-1.5B
# Run: 4

.worker_timeout)
                remove_workers.append(worker)
        for worker in remove_workers:
            self._state.remove_worker(worker)

    def _prune_tasks(self):
        remove_tasks = []
        for task in self._state.get_active_tasks():
            if task.prune(self._config):
                logger.debug("Task %s timed out (no contact for >=%ss)", task, self._config.task_timeout)
                remove_tasks.append(task)
        for task in remove_tasks:
            self._state.remove_task(task)

    def _prune_emails(self):
        if self._config.batch_emails:
            self._email_batcher.prune()

    def _get_worker(self, task):
        worker = self._state.get_worker(task)
        if worker is None:
            worker = Worker(task, self._config, self._resources)
            self._state.add_worker(worker)
        return worker

    def _get_task(self, task_id):
        task = self._state.get_task(task_id)
        if task is None:
            task = self._make_task(task_id)
            self._state.add_task(task)
        return task

    def _get_worker_request(self, task):
        worker_request = self._worker_requests.get(task)
        if worker_request is None:
            worker_request = WorkerRequest(task, self._config, self._resources)
            self._worker_requests[task] = worker_request
        return worker_request

    def _get_task_history(self, task):
        task_history = self._task_history.get(task)
        if task_history is None:
            task_history = history.TaskHistory(task)
            self._task_history.add(task_history)
        return task_history

    def _get_task_history_entry(self, task):
        task_history = self._get_task_history(task)
        return task_history.get_entry(task)

    def _get_task_history_entry_or_none(self, task):
        task_history = self._get_task_history(task)
        return task_history.get_entry_or_none(task)

    def _get_task_history_entry_or_create(self, task):
        task_history = self._get_task_history(task)
        return task_history.get_entry_or_create(task)

    def _get_task_history_entry_or_create_or_none(self, task):
        task_history = self._get_task_history(task)
        return task_history.get_entry_or_create_or_none(task)

    def _get_task_history_entry_or_create_or_none_or_none(self, task):
        task_history = self._get_task_history(task)
        return task_history.get_entry_or_create_or_none_or_none(task)

    def _get_task_history_entry_or_create_or_none_or_none_or_none(self, task):
        task_history = self._get_task_history(task)
        return task_history.get_entry_or_create_or_none_or_none_or_none(task)

    def _get_task_history_entry_or_create_or_none_or_none_or_none_or_none(self, task):
        task_history = self._get_task_history(task)
        return task_history