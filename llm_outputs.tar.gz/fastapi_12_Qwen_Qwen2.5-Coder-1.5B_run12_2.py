# Project: fastapi
# Bug: 12
# Model: Qwen/Qwen2.5-Coder-1.5B
# Run: 12_2

def HTTPBearer(
    *,
    bearerFormat: str = None,
    scheme_name: str = None,
    auto_error: bool = True,
) -> HTTPAuthorizationCredentials:
    """
    HTTP Authorization Bearer scheme.

    :param bearerFormat: Format of the bearer token.
    :param scheme_name: The name of the scheme to use for the header.
    :param auto_error: Whether to raise an exception if the header is missing.
    """
    scheme_name = scheme_name or "Bearer"
    model = HTTPBearerModel(bearerFormat=bearerFormat)
    async def __call__(request: Request) -> Optional[HTTPAuthorizationCredentials]:
        authorization: str = request.headers.get("Authorization")
        scheme, credentials = get_authorization_scheme_param(authorization)
        if not (authorization and scheme and credentials):
            if auto_error:
                raise HTTPException(
                    status_code=HTTP_403_FORBIDDEN, detail="Not authenticated"
                )
            else:
                return None
        if scheme.lower() != "bearer":
            raise HTTPException(
                status_code=HTTP_403_FORBIDDEN,
                detail="Invalid authentication credentials",
            )
        return HTTPAuthorizationCredentials(scheme=scheme, credentials=credentials)
    return __call__