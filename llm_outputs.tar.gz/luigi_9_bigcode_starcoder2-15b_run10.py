# Project: luigi
# Bug: 9
# Model: bigcode/starcoder2-15b
# Run: 10

"] = set()
    for task in set_tasks["still_pending_not_ext"]:
        upstream_tasks = worker._get_upstream_tasks(task)
        if upstream_tasks:
            upstream_tasks_status = {task_status for task_status in [task_history[task] for task in upstream_tasks]}
            if {'FAILED'} & upstream_tasks_status:
                set_tasks["upstream_failure"].add(task)
            elif {'UNKNOWN'} & upstream_tasks_status:
                set_tasks["upstream_scheduling_error"].add(task)
            elif {'PENDING'} & upstream_tasks_status:
                set_tasks["upstream_run_by_other_worker"].add(task)
            elif {'DONE'} & upstream_tasks_status:
                set_tasks["upstream_missing_dependency"].add(task)
        else:
            set_tasks["run_by_other_worker"].add(task)
    return set_tasks

"""

# +
# %%writefile test_partition_tasks.py

import unittest
from partition_tasks import _partition_tasks

class TestPartitionTasks(unittest.TestCase):
    def test_partition_tasks(self):
        worker = Worker()
        worker._add_task_history = [('task1', 'PENDING', False), ('task2', 'PENDING', False), ('task3', 'PENDING', False), ('task4', 'PENDING', False), ('task5', 'PENDING', False), ('task6', 'PENDING', False), ('task7', 'PENDING', False), ('task8', 'PENDING', False), ('task9', 'PENDING', False), ('task10', 'PENDING', False), ('task11', 'PENDING', False), ('task12', 'PENDING', False), ('task13', 'PENDING', False), ('task14', 'PENDING', False), ('task15', 'PENDING', False), ('task16', 'PENDING', False), ('task17', 'PENDING', False), ('task18', 'PENDING', False), ('task19', 'PENDING', False), ('task20', 'PENDING', False), ('task21', 'PENDING', False), ('task22', 'PENDING', False), ('task23', 'PENDING', False), ('task24', 'PENDING', False), ('task25', 'PENDING', False), ('task26', 'PENDING', False), ('task27', 'PENDING', False), ('task28', 'PENDING', False), ('task29', 'PENDING', False), ('task30', 'PENDING', False), ('task31', 'PENDING', False), ('task32', 'PENDING', False), ('task33', 'PENDING', False), ('task34',