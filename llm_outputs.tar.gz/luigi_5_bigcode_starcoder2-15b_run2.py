# Project: luigi
# Bug: 5
# Model: bigcode/starcoder2-15b
# Run: 2

"""
Task inheritance.

Usage:

.. code-block:: python

    class AnotherTask(luigi.Task):
        n = luigi.IntParameter()
        #...

    @inherits(AnotherTask):
    class MyTask(luigi.Task):
        def requires(self):
           return self.clone_parent()

        def run(self):
           print self.n # this will be defined
           #...
"""

class inherits(object):
    """
    Task inheritance.

    Usage:

   .. code-block:: python

        class AnotherTask(luigi.Task):
            n = luigi.IntParameter()
            #...

        @inherits(AnotherTask):
        class MyTask(luigi.Task):
            def requires(self):
               return self.clone_parent()

            def run(self):
               print self.n # this will be defined
               #...
    """

    def __init__(self, task_to_inherit):
        super(inherits, self).__init__()
        self.task_to_inherit = task_to_inherit

    def __call__(self, task_that_inherits):
        for param_name, param_obj in self.task_to_inherit.get_params():
            if not hasattr(task_that_inherits, param_name):
                setattr(task_that_inherits, param_name, param_obj)

        # Modify task_that_inherits by subclassing it and adding methods
        @task._task_wraps(task_that_inherits)
        class Wrapped(task_that_inherits):

            def clone_parent(_self, **args):
                return _self.clone(cls=self.task_to_inherit, **args)

        return Wrapped

"""
Task inheritance.

Usage:

.. code-block:: python

    class AnotherTask(luigi.Task):
        n = luigi.IntParameter()
        #...

    @inherits(AnotherTask):
    class MyTask(luigi.Task):
        def requires(self):
           return self.clone_parent()

        def run(self):
           print self.n # this will be defined
           #...
"""

class inherits(object):
    """
    Task inheritance.

    Usage:

   .. code-block:: python

        class AnotherTask(luigi.Task):
            n = luigi.IntParameter()
            #...

        @inherits(AnotherTask):
        class MyTask(luigi.Task):
            def requires(self):
               return self.clone_parent()

            def run(self):
               print self.n # this will be defined
               #...
    """

    def __init__(self, task_to_inherit):
        super(inherits, self).__init__()
        self.task_to_inherit = task_to_inherit

    def __call__(self,