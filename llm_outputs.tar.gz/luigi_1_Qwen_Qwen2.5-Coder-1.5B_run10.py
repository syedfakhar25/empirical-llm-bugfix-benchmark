# Project: luigi
# Bug: 1
# Model: Qwen/Qwen2.5-Coder-1.5B
# Run: 10

def MetricsHandler(self, scheduler):
    self._scheduler = scheduler

    def get(self):
        metrics = self._scheduler._state._metrics_collector.generate_latest()
        if metrics:
            metrics.configure_http_handler(self)
            self.write(metrics)