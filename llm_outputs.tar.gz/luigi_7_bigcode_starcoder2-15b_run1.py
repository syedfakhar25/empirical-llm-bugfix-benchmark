# Project: luigi
# Bug: 7
# Model: bigcode/starcoder2-15b
# Run: 1

graph")

    def _prune_workers(self):
        """
        Remove workers that are no longer alive.
        """
        for worker_id in self._state.workers.keys():
            if not self._state.workers[worker_id].is_alive():
                logger.info("Removing dead worker %s", worker_id)
                del self._state.workers[worker_id]

    def _prune_tasks(self):
        """
        Remove tasks that are no longer in the task history.
        """
        for task_id in self._state.tasks.keys():
            if not self._task_history.has_task(task_id):
                logger.info("Removing task %s", task_id)
                del self._state.tasks[task_id]

    def _prune_emails(self):
        """
        Remove emails that are no longer in the task history.
        """
        if self._config.batch_emails:
            for email_id in self._state.emails.keys():
                if not self._task_history.has_task(email_id):
                    logger.info("Removing email %s", email_id)
                    del self._state.emails[email_id]

    @rpc_method()
    def get_workers(self):
        """
        Get a list of all workers.
        """
        return self._state.workers.values()

    @rpc_method()
    def get_tasks(self):
        """
        Get a list of all tasks.
        """
        return self._state.tasks.values()

    @rpc_method()
    def get_emails(self):
        """
        Get a list of all emails.
        """
        if self._config.batch_emails:
            return self._state.emails.values()
        else:
            return []

    @rpc_method()
    def get_task(self, task_id):
        """
        Get a task by id.
        """
        return self._state.tasks[task_id]

    @rpc_method()
    def get_email(self, email_id):
        """
        Get an email by id.
        """
        if self._config.batch_emails:
            return self._state.emails[email_id]
        else:
            return None

    @rpc_method()
    def get_worker(self, worker_id):
        """
        Get a worker by id.
        """
        return self._state.workers[worker_id]

    @rpc_method()
    def get_task_history(self):
        """
        Get the task history.
        """
        return self._task_history

    @rpc_method()
    def get_config(self):
        """
        Get the scheduler config.
        """
        return self._config

    @rpc_method()
    def get_resources(self):
        """
        Get the