# Project: luigi
# Bug: 1
# Model: codellama/CodeLlama-13b-Instruct-hf
# Run: 10

class MetricsHandler(tornado.web.RequestHandler):
    def initialize(self, scheduler):
        self._scheduler = scheduler

    def get(self):
        metrics = self._scheduler._state._metrics_collector.generate_latest()
        if metrics:
            self.write(metrics)