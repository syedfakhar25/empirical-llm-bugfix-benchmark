# Project: luigi
# Bug: 5
# Model: stabilityai/stablecode-3b
# Run: 10

class inherits(object):
    """
    Task inheritance.

    Usage:

   .. code-block:: python

        class AnotherTask(luigi.Task):
            n = luigi.IntParameter()
            #...

        @inherits(AnotherTask):
        class MyTask(luigi.Task):
            def requires(self):
               return self.clone_parent()

            def run(self):
               print self.n # this will be defined
               #...
    """

    def __init__(self, task_to_inherit):
        super(inherits, self).__init__()
        self.task_to_inherit = task_to_inherit

    def __call__(self, task_that_inherits):
        for param_name, param_obj in self.task_to_inherit.get_params():
            if not hasattr(task_that_inherits, param_name):
                setattr(task_that_inherits, param_name, param_obj)

        # Modify task_that_inherits by subclassing it and adding methods
        @task._task_wraps(task_that_inherits)
        class Wrapped(task_that_inherits):

            def clone_parent(_self, **args):
                return _self.clone(cls=self.task_to_inherit, **args)

        return Wrapped

"""

from __future__ import print_function

import sys
import os
import re
import subprocess
import tempfile
import shutil
import difflib
import argparse
import textwrap
import traceback
import inspect
import collections
import json
import time
import datetime
import logging
import logging.handlers
import threading
import multiprocessing
import signal
import socket
import random
import string
import itertools
import contextlib
import functools
import collections
import warnings
import traceback
import functools
import contextlib
import threading
import multiprocessing
import signal
import socket
import random
import string
import itertools
import contextlib
import functools
import collections
import traceback
import functools
import contextlib
import functools
import collections
import traceback
import functools
import contextlib
import functools
import collections
import traceback
import functools
import contextlib
import functools
import collections
import traceback
import functools
import contextlib
import functools
import collections
import traceback
import functools
import contextlib
import functools
import collections
import traceback
import funct