# Project: luigi
# Bug: 5
# Model: Qwen/Qwen2.5-Coder-1.5B
# Run: 5

class inherits(object):
    def __init__(self, task_to_inherit):
        self.task_to_inherit = task_to_inherit

    def __call__(self, task_that_inherits):
        for param_name, param_obj in self.task_to_inherit.get_params():
            if not hasattr(task_that_inherits, param_name):
                setattr(task_that_inherits, param_name, param_obj)

        # Modify task_that_inherits by subclassing it and adding methods
        @task_that_inherits._task_wraps(task_that_inherits)
        class Wrapped(task_that_inherits):

            def clone_parent(_self, **args):
                return _self.clone(cls=self.task_to_inherit, **args)

        return Wrapped