# Project: luigi
# Bug: 7
# Model: bigcode/starcoder2-7b
# Run: 1

graph")

    def _prune_workers(self):
        """
        Remove workers that are no longer in the task graph.
        """
        for worker_id in self._state.workers:
            if worker_id not in self._worker_requests:
                logger.info("Removing worker %s", worker_id)
                self._state.remove_worker(worker_id)

    def _prune_tasks(self):
        """
        Remove tasks that are no longer in the task graph.
        """
        for task_id in self._state.tasks:
            if task_id not in self._state.task_deps:
                logger.info("Removing task %s", task_id)
                self._state.remove_task(task_id)

    def _prune_emails(self):
        """
        Remove emails that are no longer in the task graph.
        """
        for email_id in self._state.emails:
            if email_id not in self._state.email_deps:
                logger.info("Removing email %s", email_id)
                self._state.remove_email(email_id)

    def _get_task_state(self, task_id):
        """
        Get the state of a task.
        """
        return self._state.get_task_state(task_id)

    def _get_task_deps(self, task_id):
        """
        Get the dependencies of a task.
        """
        return self._state.get_task_deps(task_id)

    def _get_task_deps_and_state(self, task_id):
        """
        Get the dependencies and state of a task.
        """
        return self._state.get_task_deps_and_state(task_id)

    def _get_task_deps_and_state_and_resources(self, task_id):
        """
        Get the dependencies and state of a task.
        """
        return self._state.get_task_deps_and_state_and_resources(task_id)

    def _get_task_deps_and_state_and_resources_and_worker(self, task_id):
        """
        Get the dependencies and state of a task.
        """
        return self._state.get_task_deps_and_state_and_resources_and_worker(task_id)

    def _get_task_deps_and_state_and_resources_and_worker_and_email(self, task_id):
        """
        Get the dependencies and state of a task.
        """
        return self._state.get_task_deps_and_state_and_resources_and_worker_and_email(task_id)

    def _get_task_deps_and_state_and_resources_