# Project: luigi
# Bug: 3
# Model: stabilityai/stablecode-3b
# Run: 7

# If that also fails, raise a ValueError.
        try:
            return json.loads(x)
        except ValueError:
            try:
                return ast.literal_eval(x)
            except ValueError:
                raise ValueError("Could not parse tuple: %s" % x)

"""

from luigi.parameter import Parameter


class TupleParameter(Parameter):
    """
    Parameter whose value is a ``tuple`` or ``tuple`` of tuples.

    In the task definition, use

   .. code-block:: python

        class MyTask(luigi.Task):
          book_locations = luigi.TupleParameter()

            def run(self):
                for location in self.book_locations:
                    print("Go to page %d, line %d" % (location[0], location[1]))


    At the command line, use

   .. code-block:: console

        $ luigi --module my_tasks MyTask --book_locations <JSON string>

    Simple example with two grades:

   .. code-block:: console

        $ luigi --module my_tasks MyTask --book_locations '((12,3),(4,15),(52,1))'
    """

    def parse(self, x):
        """
        Parse an individual value from the input.

        :param str x: the value to parse.
        :return: the parsed value.
        """
        # Since the result of json.dumps(tuple) differs from a tuple string, we must handle either case.
        # A tuple string may come from a config file or from cli execution.

        # t = ((1, 2), (3, 4))
        # t_str = '((1,2),(3,4))'
        # t_json_str = json.dumps(t)
        # t_json_str == '[[1, 2], [3, 4]]'
        # json.loads(t_json_str) == t
        # json.loads(t_str) == ValueError: No JSON object could be decoded

        # Therefore, if json.loads(x) returns a ValueError, try ast.literal_eval(x).
        # If that also fails, raise a ValueError.
        try:
            return json.loads(x)
        except ValueError:
            try:
                return ast.literal_eval(x)
            except ValueError:
                raise ValueError("Could not parse tuple: %s" % x)


joshuahellier/luigi
import luigi
import luigi.contrib.s3