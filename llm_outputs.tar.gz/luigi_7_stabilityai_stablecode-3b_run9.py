# Project: luigi
# Bug: 7
# Model: stabilityai/stablecode-3b
# Run: 9

()

    def add_task(self, task):
        """
        Add a task to the scheduler.

        :param task: a Task instance
        """
        if self._paused:
            return

        if task.task_id in self._state:
            raise DuplicateTaskId(task.task_id)

        if self._config.dry_run:
            return

        if self._config.run_task(task):
            self._state.add_task(task)
            self._task_history.add_task(task)
            self._config.on_task_start(task)
            self._config.on_task_done(task)

    def add_tasks(self, tasks):
        """
        Add a list of tasks to the scheduler.

        :param tasks: a list of Task instances
        """
        for task in tasks:
            self.add_task(task)

    def add_work(self, task, worker_id):
        """
        Add a task to the scheduler.

        :param task: a Task instance
        :param worker_id: the worker id
        """
        if self._paused:
            return

        if task.task_id in self._state:
            raise DuplicateTaskId(task.task_id)

        if self._config.dry_run:
            return

        if self._config.run_task(task):
            self._state.add_task(task)
            self._task_history.add_task(task)
            self._config.on_task_start(task)
            self._config.on_task_done(task)

    def add_work_with_worker_id(self, task, worker_id):
        """
        Add a task to the scheduler.

        :param task: a Task instance
        :param worker_id: the worker id
        """
        if self._paused:
            return

        if task.task_id in self._state:
            raise DuplicateTaskId(task.task_id)

        if self._config.dry_run:
            return

        if self._config.run_task(task):
            self._state.add_task(task)
            self._task_history.add_task(task)
            self._config.on_task_start(task)
            self._config.on_task_done(task)

    def add_work_with_worker_id_and_priority(self, task, worker_id, priority):
        """
        Add a task to the scheduler.