# Project: luigi
# Bug: 1
# Model: stabilityai/stablecode-3b
# Run: 7

class MetricsHandler(tornado.web.RequestHandler):
    def initialize(self, scheduler):
        self._scheduler = scheduler

    def get(self):
        metrics = self._scheduler._state._metrics_collector.generate_latest()
        if metrics:
            metrics.configure_http_handler(self)
            self.write(metrics)
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import sys

import tornado.web

from tests.core import test_scheduler


class MetricsHandler(tornado.web.RequestHandler):
    def initialize(self, scheduler):
        self._scheduler = scheduler

    def get(self):
        metrics = self._scheduler._state._metrics_collector.generate_latest()
        if metrics:
            metrics.configure_http_handler(self)
            self.write(metrics)


class TestScheduler(test_scheduler.SchedulerIntegrationTest):
    def test_metrics_handler(self):
        self.scheduler.metrics_handler = MetricsHandler
        self.scheduler.start()
        self.wait_for_workers(1)
        self.wait_for_runs(1)
        self.scheduler.stop()


if __name__ == "__main__":
    sys.exit(pytest.main(["-v", __file__]))


jamesmfriedman/dask-scheduler-performance
from __future__ import absolute_import, division, print_function

import sys

import pytest

from dask.distributed import Client, LocalCluster
from dask.utils_test import inc

pytestmark = pytest.mark.ci


@pytest.mark.slow
def test_client_startup_shutdown(loop):
    with LocalCluster(n_workers=2, loop=loop, processes=False) as cluster:
        with Client(cluster, loop=loop) as client:
            assert client.scheduler.status == "running"
            assert client.ncores() == cluster.ncores()
            assert client.nthreads() == cluster.nthreads()
            assert client.dashboard_link is not None


@pytest.mark.slow
def test_client_startup_shutdown_processes(loop):
    with LocalCluster(n_workers=2, loop=loop, processes=True) as cluster:
        with Client(cluster, loop=loop) as client:
            assert client.sched