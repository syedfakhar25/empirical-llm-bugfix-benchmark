# Project: luigi
# Bug: 9
# Model: codellama/CodeLlama-13b-Instruct-hf
# Run: 4

by_other_worker"] = {task for (task, status, ext) in task_history
                                        if status == 'PENDING' and task not in set_tasks["failed"] and task not in set_tasks["completed"] and ext and task not in set_tasks["still_pending_ext"]}
    set_tasks["upstream_failure"] = {task for (task, status, ext) in task_history
                                     if status == 'PENDING' and task not in set_tasks["failed"] and task not in set_tasks["completed"] and ext and task not in set_tasks["still_pending_ext"] and task not in set_tasks["run_by_other_worker"]}
    set_tasks["upstream_missing_dependency"] = {task for (task, status, ext) in task_history
                                                if status == 'PENDING' and task not in set_tasks["failed"] and task not in set_tasks["completed"] and ext and task not in set_tasks["still_pending_ext"] and task not in set_tasks["run_by_other_worker"] and task not in set_tasks["upstream_failure"]}
    return set_tasks