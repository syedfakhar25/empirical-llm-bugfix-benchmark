# Project: scrapy
# Bug: 3
# Model: Qwen/Qwen2.5-Coder-1.5B
# Run: 3_10

def RedirectMiddleware(request, response, spider):
    """
    Handle redirection of requests based on response status
    and meta-refresh html tag.
    """
    if (request.meta.get('dont_redirect', False) or
            response.status in getattr(spider, 'handle_httpstatus_list', []) or
            response.status in request.meta.get('handle_httpstatus_list', []) or
            request.meta.get('handle_httpstatus_all', False)):
        return response

    allowed_status = (301, 302, 303, 307, 308)
    if 'Location' not in response.headers or response.status not in allowed_status:
        return response

    location = safe_url_string(response.headers['location'])

    redirected_url = urljoin(request.url, location)

    if response.status in (301, 307, 308) or request.method == 'HEAD':
        redirected = request.replace(url=redirected_url)
        return _redirect(redirected, request, spider, response.status)

    redirected = _redirect_request_using_get(request, redirected_url)
    return _redirect(redirected, request, spider, response.status)