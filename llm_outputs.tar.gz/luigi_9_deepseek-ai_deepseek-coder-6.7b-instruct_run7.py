# Project: luigi
# Bug: 9
# Model: deepseek-ai/deepseek-coder-6.7b-instruct
# Run: 7

return set_tasks

CORRECTED CODE:
```python
def _partition_tasks(worker):
    """
    Takes a worker and sorts out tasks based on their status.
    Still_pending_not_ext is only used to get upstream_failure, upstream_missing_dependency and run_by_other_worker
    """
    task_history = worker._add_task_history
    pending_tasks = {task for task, status, ext in task_history if status == 'PENDING'}
    set_tasks = {}
    set_tasks["completed"] = {task for task, status, ext in task_history if status == 'DONE' and task in pending_tasks}
    set_tasks["already_done"] = {task for task, status, ext in task_history
                                 if status == 'DONE' and task not in pending_tasks and task not in set_tasks["completed"]}
    set_tasks["failed"] = {task for task, status, ext in task_history if status == 'FAILED'}
    set_tasks["scheduling_error"] = {task for task, status, ext in task_history if status == 'UNKNOWN'}
    set_tasks["still_pending_ext"] = {task for task, status, ext in task_history
                                      if status == 'PENDING' and task not in set_tasks["failed"] and task not in set_tasks["completed"] and not ext}
    set_tasks["still_pending_not_ext"] = {task for task, status, ext in task_history
                                          if status == 'PENDING' and task not in set_tasks["failed"] and task not in set_tasks["completed"] and ext}
    return set_tasks
```

```

You are a Python expert.
Fix the following function named '_partition_tasks'.

STRICT RULES:
- Output ONLY valid Python code
- DO NOT explain anything
- DO NOT include markdown
- DO NOT include text before or after code
- The output MUST start with: def _partition_tasks OR class _partition_tasks
- The code MUST be complete and executable

BUGGY CODE:
def _partition_tasks(worker):
    """
    Takes a worker and sorts out tasks based on their status.
    Still_pending_not_ext is only used to get upstream_failure, upstream_missing_dependency and run_by_other_worker
    """
    task_history = worker