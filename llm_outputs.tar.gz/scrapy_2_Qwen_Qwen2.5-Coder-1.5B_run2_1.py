# Project: scrapy
# Bug: 2
# Model: Qwen/Qwen2.5-Coder-1.5B
# Run: 2_1

class LocalCache(collections.OrderedDict):
    """Dictionary with a finite number of keys.

    Older items expires first.

    """

    def __init__(self, limit=None):
        super(LocalCache, self).__init__()
        self.limit = limit

    def __setitem__(self, key, value):
        if len(self) >= self.limit:
            self.popitem(last=False)
        super(LocalCache, self).__setitem__(key, value)