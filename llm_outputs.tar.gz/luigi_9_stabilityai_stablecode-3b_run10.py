# Project: luigi
# Bug: 9
# Model: stabilityai/stablecode-3b
# Run: 10

_tasks["upstream_missing_dependency"] = set()
    for (task, status, ext) in task_history:
        if status == 'PENDING' and task not in set_tasks["failed"] and task not in set_tasks["completed"] and not ext:
            set_tasks["run_by_other_worker"].add(task)
        if status == 'PENDING' and task not in set_tasks["failed"] and task not in set_tasks["completed"] and ext:
            set_tasks["upstream_missing_dependency"].add(task)
        if status == 'FAILED' and task not in set_tasks["failed"] and task not in set_tasks["completed"]:
            set_tasks["upstream_failure"].add(task)
    return set_tasks

"""

def _partition_tasks(worker):
    """
    Takes a worker and sorts out tasks based on their status.
    Still_pending_not_ext is only used to get upstream_failure, upstream_missing_dependency and run_by_other_worker
    """
    task_history = worker._add_task_history
    pending_tasks = {task for(task, status, ext) in task_history if status == 'PENDING'}
    set_tasks = {}
    set_tasks["completed"] = {task for (task, status, ext) in task_history if status == 'DONE' and task in pending_tasks}
    set_tasks["already_done"] = {task for (task, status, ext) in task_history
                                 if status == 'DONE' and task not in pending_tasks and task not in set_tasks["completed"]}
    set_tasks["failed"] = {task for (task, status, ext) in task_history if status == 'FAILED'}
    set_tasks["scheduling_error"] = {task for(task, status, ext) in task_history if status == 'UNKNOWN'}
    set_tasks["still_pending_ext"] = {task for (task, status, ext) in task_history
                                      if status == 'PENDING' and task not in set_tasks["failed"] and task not in set_tasks["completed"] and not ext}
    set_tasks["still_pending_not_ext"] = {task for (task, status, ext) in task_history
                                          if status == 'PENDING' and task not in set_tasks["failed"] and task not in set_tasks["completed"] and ext}
    set_tasks["run_by_other_worker"] = set()
    set_tasks["upstream_failure"]